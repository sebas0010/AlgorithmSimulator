#pragma once

#include "Engine.h"
#include "Level/Level.h"

class Game : public Engine
{
public:

	Game();
	~Game();

	// �޸� ���� �Լ�
	void CleanUp() override;

	void CreatePauseLevel();
	void ToggleMenu();
	void ReturnToMainMenu();

private:
	Level* backLevel = nullptr;
};